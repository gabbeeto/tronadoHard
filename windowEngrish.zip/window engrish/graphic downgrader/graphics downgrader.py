import os
import time
import shutil


# copied from somewhere else 
def convert(lst):
   res_dict = {}
   for i in range(0, len(lst), 2):
       res_dict[lst[i]] = lst[i + 1]
   return res_dict

optionofFile = f"{os.getcwd()}\\optionsof.txt"
optionFile = f"{os.getcwd()}\\options.txt"
texturePack = f"{os.getcwd()}\\Splotch+v1.3.5.zip"
userDirectory = os.path.expanduser('~')
minecraftFolder = f"{userDirectory}\\appdata\\roaming\\.minecraft"

print("---Reading the minecraft configurations---")
# deal with vanilla settings
minecraftFiles = os.listdir(f"{userDirectory}\\appdata\\roaming\\.minecraft")


print("---looking for setting backUps---")
optionsBackUp = False
if "optionsBackUpPorGabbeeto" in minecraftFiles:
    optionsBackUp = True
    print("Setting backUps has been found!!")
else:
    print("Setting backUps has not been found!!")



optifineSettingsFound = False
if "optionsof.txt" in minecraftFiles:
    optifineSettingsFound = True
    print("Optifine setting has been found!! (only changed some attributes related to graphics)")
else:
    print("Optifine settings has not been found :T (changed all the attributes)")

normalSettingsFound = False
if "options.txt" in minecraftFiles:
    normalSettingsFound = True
    print("Vanilla Minecraft setting has been found!! (only changed some attributes related to graphics)")
else:
    print("Vanilla Minecraft settings has not been found :T (changed all the attributes)")

if normalSettingsFound == True and optifineSettingsFound == True:
    os.chdir(minecraftFolder)
    os.mkdir("optionsBackUpPorGabbeeto")
    shutil.copyfile(f"{minecraftFolder}\\options.txt", f"{minecraftFolder}\\optionsBackUpPorGabbeeto\\options.txt")
    shutil.copyfile(f"{minecraftFolder}\\optionsof.txt", f"{minecraftFolder}\\optionsBackUpPorGabbeeto\\optionsof.txt")


if normalSettingsFound == True:
    print("---Reading Vanilla Minecraft settings---")
    optionFileAcess = open(f"{userDirectory}\\appdata\\roaming\\.minecraft\\options.txt","r")
    optionContent = optionFileAcess.read()
    removedData = [data for data in optionContent.split("\n") if len(data)>2 ]
    joinedData = "".join(removedData)

    newData = []
    for data in removedData:
        newData.append(data.split(":")[0])
        newData.append(data.split(":")[1])

    minecraftOptions = convert(newData)


    print("---Preparing new vanilla Minecraft settings to put them in the Minecraft Folder---")
    minecraftOptions["advancedItemTooltips"] = "false"
    #  graphics: fast
    minecraftOptions["graphicsMode"] = "0"
    #  smoth lighting
    minecraftOptions["ao"] = "false"
    minecraftOptions["entityDistanceScaling"] = "0.5"
    minecraftOptions["renderDistance"] = "6"
    minecraftOptions["simulationDistance"] = "6"
    minecraftOptions["prioritizeChunkUpdates"] = "0"
    # animation
    minecraftOptions["particles"] = "2"
    minecraftOptions["mipmapLevels"] = "0"
    minecraftOptions["fovEffectScale"] = "0.0"
    minecraftOptions["biomeBlendRadius"] = "0"
    minecraftOptions["enableVsync"] = "false"
    minecraftOptions["screenEffectScale"] = "0.0"
    minecraftOptions["fovEffectScale"] = "0.0"
    minecraftOptions["darknessEffectScale"] = "0.0"
    minecraftOptions["telemetryOptInExtra"] = "false"
    minecraftOptions["entityShadows"] = "false"
    minecraftOptions["fullscreen"] = "true"
    minecraftOptions["attackIndicator"] = "0"
    minecraftOptions["showSubtitles"] = "false"
    minecraftOptions["hideLightningFlashes"] = "false"

    # detail settings
    minecraftOptions["renderClouds"] = "false"
    minecraftOptions["showAutosaveIndicator"] = "false"
    minecraftOptions["bobView"] = "false"
    minecraftOptions["resourcePacks"] = "[\"vanilla\",\"mod_resources\",\"file/Splotch+v1.3.5.zip\"]"


    print("---Copying those new Vanilla Minecraft attributes---")
    newArrayForVanillaSettings = []
    for key,value in minecraftOptions.items():
        keyAndValue = f"{key}:{value}"
        newArrayForVanillaSettings.append(keyAndValue)
    optionContent = "\n".join(newArrayForVanillaSettings)
    vanillaFile = open(f"{userDirectory}\\appdata\\roaming\\.minecraft\\options.txt","w")
    vanillaFile.write(optionContent)
else:
    print("---Copying Vanilla Minecraft attributes---")
    shutil.copy(optionFile,f"{minecraftFolder}\\options.txt")


if optifineSettingsFound:
    # deal with vanilla settings
    print("---Reading optifine settings---")
    optionFileAcessForOptifine = open(f"{userDirectory}\\appdata\\roaming\\.minecraft\\optionsof.txt","r")
    optifineOptionContent = optionFileAcessForOptifine.read()
    optifineRemovedData = [data for data in optifineOptionContent.split("\n") if len(data)>2 ]
    joinedData = "".join(optifineRemovedData)

    newDataForOptifine = []
    for data in optifineRemovedData:
        newDataForOptifine.append(data.split(":")[0])
        newDataForOptifine.append(data.split(":")[1])

    print("---Preparing new Optifine settings to put them in the Minecraft Folder---")
    minecraftOptionsForOptifine = convert(newDataForOptifine)

    minecraftOptionsForOptifine["ofRain"] = "0"
    minecraftOptionsForOptifine["ofMipmapType"] = "0"
    minecraftOptionsForOptifine["ofBetterGrass"] = "0"
    minecraftOptionsForOptifine["ofWeather"] = "false"
    minecraftOptionsForOptifine["ofShowGlErrors"] = "false"
    minecraftOptionsForOptifine["ofDynamicLights"] = "false"
    minecraftOptionsForOptifine["ofDynamicFov"] = "false"
    minecraftOptionsForOptifine["ofAaLevel"] = "0"
    minecraftOptionsForOptifine["ofAfLevel"] = "1"
    minecraftOptionsForOptifine["ofAoLevel"] = "0.0"

    minecraftOptionsForOptifine["ofSmoothWorld"] = "true"
    # quality
    minecraftOptionsForOptifine["ofBetterGrass"] = "0"
    minecraftOptionsForOptifine["ofCustomSky"] = "false"
    minecraftOptionsForOptifine["ofCustomFonts"] = "false"
    minecraftOptionsForOptifine["ofConnectedTextures"] = "3"
    minecraftOptionsForOptifine["ofCustomEntityModels"] = "false"
    minecraftOptionsForOptifine["ofRandomEntities"] = "false"
    minecraftOptionsForOptifine["ofBetterSnow"] = "false"
    minecraftOptionsForOptifine["ofSunMoon"] = "false"
    minecraftOptionsForOptifine["ofNaturalTextures"] = "false"
    minecraftOptionsForOptifine["ofCustomColors"] = "false"
    minecraftOptionsForOptifine["ofCustomItems"] = "false"
    minecraftOptionsForOptifine["ofCustomGuis"] = "false"
    minecraftOptionsForOptifine["ofEmissiveTextures"] = "false"
    minecraftOptionsForOptifine["ofSmartAnimations"] = "true"
    minecraftOptionsForOptifine["ofFastRender"] = "true"
    minecraftOptionsForOptifine["ofFastMath"] = "true"
    minecraftOptionsForOptifine["ofTelemetry"] = "2"
    minecraftOptionsForOptifine["ofClouds"] = "3"
    minecraftOptionsForOptifine["ofCloudsHeight"] = "0.0"
    minecraftOptionsForOptifine["ofLazyChunkLoading"] = "true"
    minecraftOptionsForOptifine["ofSmoothFps"] = "false"
    minecraftOptionsForOptifine["ofChunkUpdates"] = "1"
    minecraftOptionsForOptifine["ofChunkUpdatesDynamic"] = "true"

    # animation
    minecraftOptionsForOptifine["ofAnimatedWater"] = "2"
    minecraftOptionsForOptifine["ofAnimatedFire"] = "false"
    minecraftOptionsForOptifine["ofAnimatedPortal"] = "false"
    minecraftOptionsForOptifine["ofAnimatedRedstone"] = "false"
    minecraftOptionsForOptifine["ofAnimatedFlame"] = "false"
    minecraftOptionsForOptifine["ofVoidParticles"] = "false"
    minecraftOptionsForOptifine["ofRainSplash"]= "false"
    minecraftOptionsForOptifine["ofPotionParticles"] = "false"
    minecraftOptionsForOptifine["ofAnimatedTerrain"]= "false"
    minecraftOptionsForOptifine["ofFireworkParticles"]= "false"
    minecraftOptionsForOptifine["ofAnimatedLava"] = "2"
    minecraftOptionsForOptifine["ofPortalParticles"]= "false"
    minecraftOptionsForOptifine["ofAnimatedExplosion"] = "false"
    minecraftOptionsForOptifine["ofAnimatedSmoke"] = "false"
    minecraftOptionsForOptifine["ofWaterParticles"]= "false"
    minecraftOptionsForOptifine["ofDrippingWaterLava"]= "false"
    minecraftOptionsForOptifine["ofAnimatedTextures"]= "false"


    # details
    minecraftOptionsForOptifine["ofTrees"] = "1"
    minecraftOptionsForOptifine["ofVignette"] = "1"
    minecraftOptionsForOptifine["ofFogType"] = "3"
    minecraftOptionsForOptifine["ofFogStart"] = "0.2"
    minecraftOptionsForOptifine["ofShowCapes"] = "3"

    minecraftOptionsForOptifine["ofHeldItemTooltips"] = "false"
    minecraftOptionsForOptifine["ofAlternateBlocks"] = "false"
    minecraftOptionsForOptifine["ofStars"] = "false"
    minecraftOptionsForOptifine["ofSwampColors"] = "false"
    minecraftOptionsForOptifine["ofSky"] = "false"
    minecraftOptionsForOptifine["ofRain"] = "3"

    newArrayForOptifineSettings = []
    for key,value in minecraftOptionsForOptifine.items():
        keyAndValue = f"{key}:{value}"
        newArrayForOptifineSettings.append(keyAndValue)

    optionofContent = "\n".join(newArrayForOptifineSettings)

    print("---copying optifine attributes---")
    optifineFile = open(f"{userDirectory}\\appdata\\roaming\\.minecraft\\optionsof.txt","w")
    optifineFile.write(optionofContent)
else:
    print("---making a new setting for optifine---")
    shutil.copy(optionofFile,f"{minecraftFolder}\\optionsof.txt")


print("---installing a resourcepack with less pixels---")
resourcePackExists = False
if "resourcepacks" in minecraftFiles:
    resourcePackExists = True

if resourcePackExists == False:
    os.chdir(minecraftFolder)
    os.mkdir("resourcepacks")

shutil.copyfile(texturePack,f"{minecraftFolder}\\resourcepacks\\Splotch+v1.3.5.zip")

print("---the process has been finished--- (hopefully you're going to enjoy TronadoHard inside a toaster... :D)")
time.sleep(2)
