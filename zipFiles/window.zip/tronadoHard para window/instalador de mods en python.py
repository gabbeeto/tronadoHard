import shutil
import json
import os
import time

def seperator():
    os.system('cls')
    time.sleep(4)
    endOfLine = "\n" * 3
    print("-" * 100,end = endOfLine)

def removeFirstItem(array,amountOfTimes):
    for number in range(amountOfTimes):
        array.pop(0)

instalationFolder = f"{os.getcwd()}"
    

optionalModFolder = f"{os.getcwd()}\\mods opcionales"
requiredModFolder = f"{os.getcwd()}\\mods requeridos"
userDirectory = os.path.expanduser('~')
minecraftFolder = f"{userDirectory}\\appdata\\roaming\\.minecraft"

print('Bienvenido al instalador TronadoHard.\n(Antes de seguir con esta Instalación, deberias instalar forge abriendo el "instalador para forge" con java)\n\nElija una de las siguientes opciones:')
bdComputer = input("Presioná  el número '1' y la tecla 'enter' si querés instalar los mods para computadora mala.\nPresioná  el número '2' y la tecla 'enter' si querés instalar mods para computadora buena.\nTu respuesta:")
badComputer = bdComputer.lower()
isBadComputer = False
if badComputer.startswith('1') or badComputer.startswith('one') or badComputer.startswith('uno'):
    isBadComputer = True;

seperator()

parentForMinecraftDirectory = f"{userDirectory}\\appdata\\roaming"
os.chdir(f"{parentForMinecraftDirectory}/.minecraft")
dirItems = os.listdir()


print("Verificando si hay un backup/respaldo creado por este instalador...")
doesBackUpExist = False
modsFolderExists = False
for item in dirItems:
    if item == 'modBackUpPorGabbeeto':
        doesBackUpExist = True
    elif item == 'mods':
        modsFolderExists = True

if modsFolderExists == False:
    os.mkdir("mods")
        
if doesBackUpExist == False and modsFolderExists == True:
    print("-Backup/respaldo no ha sido encontrado-")
    userWantsBackup = input("\n¿Quieres que se cree un backup/respaldo de la carpeta de Minecraft con los mods anteriores?\n(los mods se te van a borrar cuando copiemos los nuevos mods)\n[s/si-n/no]\nTu respuesta:")
    backupWanted = userWantsBackup.lower()
    if backupWanted.startswith('s') or backupWanted.startswith('y'):
        print("Creando un backup...")
        minecraftDirectory = f'{os.getcwd()}\\mods'
        backUpDirectory = f'{os.getcwd()}\\modBackUpPorGabbeeto'
        shutil.copytree(minecraftDirectory,backUpDirectory)
        print("-Backup/respaldo ya ha hizo creado-")
else:
    print("-Backup/respaldo ha sido encontrado-")

seperator()

versionExists = False
listOfVersion = os.listdir(f"{minecraftFolder}\\versions")
if "1.20.1-forge-47.1.43" in listOfVersion:
    versionExists = True

# check this section on the linux file
tronadoHardFolderExists = False
if "TronadoHard" in listOfVersion:
    tronadoHardFolderExists = True

    # check this entire part too
if versionExists == True and tronadoHardFolderExists == False:
    # adding making a folder
    os.chdir(f"{minecraftFolder}\\versions")
    os.mkdir("TronadoHard")
    listOfFilesInVersionFolder = os.listdir(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43")
    jarFileExists = False
    if "1.20.1-forge-47.0.43.jar" in listOfFilesInVersionFolder:
        jarFileExists = True

    # checking so we can copy
    if jarFileExists:
        shutil.copy(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.jar",f"{minecraftFolder}\\versions\\TronadoHard\\TronadoHard.jar")

    # copying again instead of renaming 
    shutil.copy(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.json",f"{minecraftFolder}\\versions\\TronadoHard\\TronadoHard.json")

    # edit the new file instead of the old one 
    with open(f"{minecraftFolder}\\versions\\TronadoHard\\TronadoHard.json","r") as jsonFile:
        jsonInPython = json.load(jsonFile)
    jsonInPython['id'] = "TronadoHard"

    # same here 
    with open(f"{minecraftFolder}\\versions\\TronadoHard\\TronadoHard.json","w") as jsonFile:
        json.dump(jsonInPython,jsonFile)

    # if jarFileExists:
    #     os.rename(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.jar",f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\TronadoHard.jar")
    # os.rename(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.json",f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\TronadoHard.json")

seperator()

# check this one too
launcherProfileExists = False
if "launcher_profiles.json" in dirItems:  
    launcherProfileExists = True

if launcherProfileExists == True:
    with open(f"{minecraftFolder}\\launcher_profiles.json", "r") as profileJsonFile:
        launcherProfile = json.load(profileJsonFile)

    previouslyCreated = False
    # check this one too
    if "noRemuevasEstoPorfavorQuePrevieneLaReinstalacionDeVersiones" in dirItems:
        previouslyCreated = True

    if previouslyCreated == False:
        launcherProfile["profiles"]["trHard"] = {"name": "serie de tronadoHard", "lastVersionId" : "TronadoHard","type": "custom", "icon":"data:image/png;base64,AAABAAMAMDAAAAEACACoDgAANgAAACAgAAABAAgAqAgAAN4OAAAQEAAAAQAIAGgFAACGFwAAKAAAADAAAABgAAAAAQAIAAAAAAAACQAAAAAAAAAAAAAAAQAAAAAAAPX08wBMOSoAvbaxANPOywD6+fkAPioZAK+noADW0s4AnpSMAP39/ADFv7oAtKymAGpaTQDa19QA29fUAEs4KACEd20A9fT0AOPg3QCropsATz0uAPn49wCJfHMA5+XjAD4qGgDo5eMAPyoaAGVVSACMgHYA/f39AMW/uwD+/f0As6ukAEMvIADa1tIAopiQAJCFfADv7uwAt7CqALiwqgBtXlEAzsjEAPTz8gBLOCkAcmNXAOPg3gBhUEMA5uThAD0pGACdk4sAxL65AEEuHgDr6ecAQi4eAGlZTADa1tMAj4R6AO/u7QDw7u0ApZyUAG5eUgDf29kAu7SuAIN2bACqoZoAX09BANDMyADRzMgA9/f2AE88LQD49/YAwLm0AD0pGQA+KRkAnJKJAGRURwCLf3UA/Pz8AEEtHACyqqMAemxhAOvp6ADZ1dEAoZePAEUyIgC3r6kA3drXAIJ1agBxYlYAYE9CAId6cAD49/cAnJKKAJ2SigD7+/oAQS0dAOro5gDZ1dIAV0U3AH5wZQBGMiMAbV1RAMvGwQDe2tgAXEo9AEk2JgC6s60A4d7bAKmgmQD39vUA5ePhAObj4QBkU0YA1dDNAPv7+wD8+/sAsamiANjU0ACglo4AaFhMAP///gCPg3oARDEhALauqADc2dYA3dnWAPLx8ABJNicAqJ+XALuzrgCXjIMA9/b2AK2knQDUz8sAm5GJAJyRiQD6+vkAUT8wAOnn5QBALBwAQSwcANjU0QDZ1NEAVkQ2AP///wDu7OsAo5qSAMrFwADd2dcA8fDuAEg1JQC5sqwAb2BTAODd2gCpn5gA5eLgAIl9cwA/KxoA+/r6AOrn5gBVQzQAjoJ5AO3r6QC1racAa1tOANvY1QDc2NUAy8XBAM7JxACWi4IATTosAFA+LwDBu7YA+vn4AMK7tgA/KxsA6ObkAEArGwBmVkkA/v7+AFVDNQD//v4Ae25jAHxuYwDt6+oARDAhANrX0wBrW08AycS/AEc0JAC5sasA39zZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABfX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX1+MjIyMX19fX19fX19fX19fX4uMjIxfX19fX19fX19fX19fX19fX19fX19fX19frwyje3smtjUYi19fX19fi52vcCB7ewsbr19fX19fX19fX19fX19fX19fX19fX19fBT8dkJCQE0wsqjWvGq9ff0uhOIiQkHO3BV9fX19fX19fX19fX19fX19fX19fX19fBT8dkJCQQBA5jT6aUzt7QzqAEB2QkHK3BV9fX19fX19fX19fX19fX19fX19fX19fnaSikJCQN1hVkJCQkJCQkAc8ApCQkBlLr19fX19fX19fX19fX19fX19fX19fX19fX195RpCQkLBsv5CQkJCQJRMHkJCQAFqLX19fX19fX19fX19fX19fX19fX19fX19fX4tUklFekJBbm16QkJC1ipWQswAvhyFOX19fX19fX19fX19fX19fX19fX19fX19fX1+LVGhXZh2QeJCQkJCQs5CwdiiPeotfX19fX19fX19fX19fX19fX19fX19fX19fX19fX69Jq7yQkJCQkJCQkCpQGBixX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fMJyQkJCQkJCQkKe9i19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fSBaQkJCQkJCQkISxX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fTouxr69JKwqQkJCQkJCQkE+LX19fX19fX19fX19fX19fX19fX19fX19fX19fXxqLloliaEEsvnOQkJCQkJCQkIUBi19fX19fX19fX19fX19fX19fX19fX19fX1+dZFhAqL8XNJFEkJCQkJCQkJCQkIO3BV9fX19fX19fX19fX19fX19fX19fX19fi4uyaiqQkJCQkJCQkJCQkJCQkJCQkJADoK9fX19fX19fX19fX19fX19fX19fX1+vK6mfkJCQkJBbBJAJs5CQkJCQkJCQkJCQPhQaX19fX19fX19fX19fX19fX19fX68urnKQkJCQkJAtJZCKiJCQkJCQkJCQkJCQHzJZnYtfX19fX19fX19fX19fX1+LNWNrkJCQkJCQkJCTYLMpW5CQkJCQkJCQkJCQkJASJImvGotfX19fX19fX19fX69phn6QkJCQkJCQkLUGGa0LRpCQkJCQkJCQkJCQkJCQTQ4xdw+Li4uLX19fX19fi7Qnc5CQkJCQkJCQkASCsDoIFZCQs15tlVFvv3VCvKyXdBMjHDarRRQBNV9fX19fX2VdXUpKSkpKSkpKXIK7HkdMBJCQs54RlbiKbi1rPVZ8pg4OpZRnZ5mBlk5fX19fX4saGBgYGBgYGBgYGBg1D72YcY6NjVJhYSI3Nzc3ug0NDQ0NDQ0NDX0nll9fX19fX19fX19fX19fX19fX19fi4u5KwEBAQEBAQEBAQEBAQEBAQEBAQEBAQF/M19fX19fX19fX19fX19fX19fX19fX19fi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX19fX18AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAoAAAAIAAAAEAAAAABAAgAAAAAAAAEAAAAAAAAAAAAAAABAAAAAAAAzsnFAPX08wBMOSoAc2RYAGJRRACJfHIA+vn5AD4qGQDs6ugA29fUAFhHOQBZRzkAbl9TAODc2gDNyMMAlYqBALy1rwDj4N0A+Pj3AE89LgD5+PcAUD0uAD4qGgA/KhoA1tLPANfSzwCMgHYAVEI0AP79/QDa1tIAkYV8AO/u7AC4sKoAXEs9AHJjVwBhUEMA0s3KAFA9LwCvpp8A1dHNAPz8+wDEvrkAQi4eANrW0wBYRjgAycO/AH5xZgBHMyQAlImAAPj39gDAubQA5uTiAD0pGQDn5OIAPikZAGRURwBlVEcA1tHOAPz8/ADFvroAemxhAOvp6ABWRTYARTIiALevqQB/cWcAbF1QAN3a1wDz8vEASjcoALu0rwCYjYQAh3pwAJ2SigBSQDEAw724AEEtHQDZ1dIAV0U3AEYyIwCkm5MAy8bBAN7a2ADh3tsA9vb1APf29QB0ZloA5uPhAEAsGwD8+/sA6+jnAMfBvABFMSEA7uzqAGtcTwDd2dYAWkk7APLx8ABJNicAcGFVAL63sQBOOy0AraSdAPr6+QBRPzAAQCwcAEEsHADY1NEA////AMfBvQB8b2QA3dnXAEg1JQCCdGoA4N3aAPb19AC+t7IAdGVZADwnFwCakIcAY1JFAPr6+gCwqKEA19PPAMbAuwBEMCAA29jVANzY1QDKxcEAWkg6AIBzaADy8O8A4N3bAJaLggBLOSkAvbawAKyjnAD5+fgAPysbAOjm5ABAKxsA19PQANjT0AD+/v4AVUM1AEQwIQCShn0AubGrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMKj8/XGlqTExMTExpkT8/KkxMTExMTExMTExMTExMTIo4O4CTeC8WNjYHkYGIUUsEikxMTExMTExMTExMTExMFgMUbFoeh0kFSEdGME1sVQwWTExMTExMTExMTExMTEyMgX9seSZbbGyPbBhQRGyOPlhMTExMTExMTExMTExMTEyKVg1nWVMBbGwGhBJzfmOKTExMTExMTExMTExMTExMTExMkEEJbI9sbGw6QEJKTExMTExMTExMTExMTExMTExMTExYdnEobGxsbENKNGlMTExMTExMTExMTExMTExMTExpjIp2gihsbGxsKX1MTExMTExMTExMTExMTExMTGkXT2gsIXUnbGxsbGw5AmlMTExMTExMTExMTExMTEwXZRptcosIVGxsbGxsbDEuNkxMTExMTExMTExMTExpTCIAKGxsZ48cbGxsbGxsbF83B0xMTExMTExMTExMikV3H2xsbI8RiT2PbGxsbGxsbG88XBZpTExMTExMTGlgdDpsbGxsBi1hJGxsbGxsbGyPbIMgVoYWB4pMTExYLBCLNTMzMzUJZhFkbGw6c11XQycOfDJ6km5uI2lMTExFCk5OTk5OThsLXoUNUl8JHWuOjXt7GY1NK18PikxMTGmMjIyMjIyMaYwWcBUTExMVFRUVFRUVFRUVJWJMTExMTExMTExMTExMTExqaWlpaWlpaWlpaWlpaWlpaUxMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgAAAAQAAAAIAAAAAEACAAAAAAAAAEAAAAAAAAAAAAAAAEAAAAAAADUz8sA5+TiAPr5+QDDvLcAVEIzAEczJADy8e8A0s3JAEMvHwDl4uAAVkQ2APj39wDQy8cAmY6FAEEtHQBUQjQA9vX1AFA+LwBDLyAAl4yDAD8rGwBAKxsA3drXAN7a1wCZjoYAQS0eAO3r6QCkm5MATDorAE06KwCTiH8AXEs9AP7+/gCnnZYA6eflAFZFNgD4+PcAoZePAOvp6ABKNicAfW9kAOfl4wDj4d4Av7mzAJ+VjQBINCUAQzAgAHdpXQBALBsAV0U3APn4+ACLfnQAnpOLAEYyIwBCLh4AraSdAFVDNQCIfHIAQCwcAHhpXgBzZVkAU0EzAN7b2ADOyMQAPioaAD8qGgBOOywAXUw+AP///wDb19QATDkqAFtKPADGwLsAbl9TAPn5+ADZ1dIASjcoAJGFfACNgXcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODjoODg4ODjoODg4ODg4ODi4cBUBAQDVGEg4ODg4ODhRDBxs7SS80DEcUDg4ODg46QgMJASQiPisdOg4ODg4ODhQnTTJEGihMOg4ODg4OFQ4RMU4CRBYdFA4ODg4OQSMhFykQREQLOTAVDg4ONjxLREoBBkREICYTOAgZDkYzJSwNHkgqRQA/SDcYHxQOFEBAQDpCBD0EBA8KIy0ODg4ODg4OOjo6Ojo6OjoODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODg4ODgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\u003d"}
        os.chdir(minecraftFolder)
        os.mkdir('noRemuevasEstoPorfavorQuePrevieneLaReinstalacionDeVersiones')

    with open(f"{minecraftFolder}\\launcher_profiles.json", "w") as profileJsonFile:
        json.dump(launcherProfile,profileJsonFile)

seperator()
optionalMods = [
                "appleskin-forge-mc1.20.1-2.5.1.jar",
                "BetterThirdPerson-Forge-1.20-1.9.0.jar",
                "tia-1.20-1.1-forge.jar",
                "guiclock-1.20.1-4.3.jar",
                "collective-1.20.1-7.8.jar",
                "badpackets-forge-0.4.3.jar",
                "wthit-forge-8.4.1.jar",
                "InventoryProfilesNext-forge-1.20-1.10.9.jar",
                "kotlinforforge-4.3.0-all.jar",
                "libIPN-forge-1.20-4.0.1.jar",
                "Xaeros_Minimap_23.8.4_Forge_1.20.jar",
                "jei-1.20.1-forge-15.2.0.27.jar",
                "plasmovoice-forge-1.20.1-2.0.7.jar"]

if isBadComputer == True:
    rsp = input("Del 1 a 5.. ¿Que tal mala es tu PC?\n(Menos mods opcionales instalados mientras el número sea mayor):\n\n1.Minecraft sin optifine con gráficos bajos funciona con 60 FPS promedio.\n(Obtendrás todos los mods opcionales excepto 'what the hell is that' y su dependencia y otros mods que hacen minecraft lucir mejor. Esos mods son agregados cuando elejis la opcion 2 anteriormente para instalar mods para pc buenas)\nMods:\n-Inventory Profiler Next\n-Kotling For Forge(Dependencia de 'Inventory')\n-LibIPN(Dependencia de 'Inventory')\n-Just Enough Items\n-Xaero's minimap\n-Plasmo voice\n\n2.Minecraft sin optifine con gráficos bajos funciona con 50 FPS promedio.\n(Obtendrás todos los mods opcionales excepto 'What the hell is that'(con 'Bad packets') e 'Inventory Profiler Next' con sus dependencias)\nMods:\n-Just Enough Items\n-Xaero's minimap\n-Plasmo Voice \n\n3.Minecraft sin optifine con gráficos bajos funciona a 40 FPS promedio.\n(Igual que la opción anterior pero sin 'just Enough Items')\nMods:\n-Xaero's minimap\n-Plasmo Voice\n\n4.Minecraft sin optifine con gráficos bajos funciona a 30 FPS promedio.\n(PC de gobierno)\nMod:\n-Plasmo voice\n\n5.Minecraft sin optifine con gráficos bajos a 20 FPS\n(Absoluta mierda)\n-Sin mods opcionales\nTu respuesta(Lee todo antes de continuar):")
    response = rsp.lower()
    if response.startswith("1") or response.startswith("one") or response.startswith("uno"):
        removeFirstItem(optionalMods,7) 
    if response.startswith("2") or response.startswith("two") or response.startswith("do"):
        removeFirstItem(optionalMods,10) 
    if response.startswith("3") or response.startswith("three") or response.startswith("tre"):
        removeFirstItem(optionalMods,11) 
    if response.startswith("4") or response.startswith("four") or response.startswith("cuatr"):
        removeFirstItem(optionalMods,12) 
    if response.startswith("5") or response.startswith("five") or response.startswith("cinc"):
        optionalMods = []
seperator()

print("-Preparando mods para ser copiado-")
os.chdir(requiredModFolder)
requiredMods = os.listdir()

seperator()

modsFolderDetected = False
os.chdir(minecraftFolder)
minecraftItems = os.listdir()
if "mods" in minecraftItems:
    modsFolderDetected = True

if modsFolderDetected == True:
    print("-Vaciando carpeta de mods-")
    shutil.rmtree(f"{minecraftFolder}\\mods")
os.mkdir('mods')

print("-Copiando mods requeridos-")
for mod in requiredMods:
    shutil.copy(f"{requiredModFolder}\\{mod}",f"{minecraftFolder}\\mods\\{mod}")

print("-Copiando mods opcionales-")
for mod in optionalMods:
    shutil.copy(f"{optionalModFolder}\\{mod}",f"{minecraftFolder}\\mods\\{mod}")

seperator()

input("Mods de TronadoHard instalados! \nSi tenés problemas de rendimiento, podés usar el 'Bajador De Gráficos 3000'\n(Para más informacion, mira el tutorial o lee las instrucciones de como usarlo, o de como bajar los gráficos manualmente). \nPreciona enter y espera 2 segundos para que la instalacion completa termine exitosamente!\n(no cierres esta ventana, preciona enter y se cerrara solo)")


time.sleep(2)
