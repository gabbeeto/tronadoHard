import shutil
import json
import os
import time

def seperator():
    os.system('cls')
    time.sleep(4)
    endOfLine = "\n" * 3
    print("-" * 100,end = endOfLine)

def removeFirstItem(array,amountOfTimes):
    for number in range(amountOfTimes):
        array.pop(0)

instalationFolder = f"{os.getcwd()}"
    

optionalModFolder = f"{os.getcwd()}\\mods opcionales"
requiredModFolder = f"{os.getcwd()}\\mods requeridos"
userDirectory = os.path.expanduser('~')
minecraftFolder = f"{userDirectory}\\appdata\\roaming\\.minecraft"

print('Bienvenido al instalador TronadoHard.\nElija una de las siguientes opciones:\n')
bdComputer = input("Presioná  el número '1' y la tecla 'enter' si querés instalar los mods para computadora mala.\nPresioná  el número '2' y la tecla 'enter' si querés instalar mods para computadora buena.\nTu respuesta:")
badComputer = bdComputer.lower()
isBadComputer = False
if badComputer.startswith('1') or badComputer.startswith('one') or badComputer.startswith('uno'):
    isBadComputer = True;

seperator()

# get user directory
parentForMinecraftDirectory = f"{userDirectory}\\appdata\\roaming"
os.chdir(f"{parentForMinecraftDirectory}/.minecraft")
dirItems = os.listdir()


print("Verificando si hay un backup/respaldo creado por este instalador...")
doesBackUpExist = False
modsFolderExists = True
for item in dirItems:
    if item == 'modBackUpPorGabbeeto':
        doesBackUpExist = True
    elif item == 'mods':
        modsFolderExists = True

if modsFolderExists == False:
    os.mkdir("mods")
        
if doesBackUpExist == False and modsFolderExists == True:
    print("-Backup/respaldo no ha sido encontrado-")
    userWantsBackup = input("\n¿Quieres que se cree un backup/respaldo de la carpeta de Minecraft con los mods anteriores?\n(los mods se te van a borrar cuando copiemos los nuevos mods)\n[s/si-n/no]\nTu respuesta:")
    backupWanted = userWantsBackup.lower()
    if backupWanted.startswith('s') or backupWanted.startswith('y'):
        print("Creando un backup...")
        minecraftDirectory = f'{os.getcwd()}\\mods'
        backUpDirectory = f'{os.getcwd()}\\modBackUpPorGabbeeto'
        shutil.copytree(minecraftDirectory,backUpDirectory)
        print("-Backup/respaldo ya ha hizo creado-")
else:
    print("-Backup/respaldo ha sido encontrado-")

seperator()

versionExists = False
listOfVersion = os.listdir(f"{minecraftFolder}\\versions\\")
if "1.20.1-forge-47.1.43" in listOfVersion:
    versionExists = True

if versionExists == True:
    listOfFilesInVersionFolder = os.listdir(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43")
    jarFileExists = False
    if "1.20.1-forge-47.0.35.jar" in listOfFilesInVersionFolder:
        jarFileExists = True

    with open(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.json","r") as jsonFile:
        jsonInPython = json.load(jsonFile)
    jsonInPython['id'] = "TronadoHard";

    with open(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.json","w") as jsonFile:
        json.dump(jsonInPython,jsonFile)

    if jarFileExists:
        os.rename(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.jar",f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\TronadoHard.jar")
    os.rename(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\1.20.1-forge-47.1.43.json",f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43\\TronadoHard.json")
    os.rename(f"{minecraftFolder}\\versions\\1.20.1-forge-47.1.43",f"{minecraftFolder}\\versions\\TronadoHard")

seperator()

optionalMods = [
                "badpackets-forge-0.4.3.jar",
                "wthit-forge-8.4.1.jar",
                "InventoryProfilesNext-forge-1.20-1.10.9.jar",
                "kotlinforforge-4.3.0-all.jar",
                "libIPN-forge-1.20-4.0.1.jar",
                "Xaeros_Minimap_23.8.4_Forge_1.20.jar",
                "jei-1.20.1-forge-15.2.0.27.jar",
                "plasmovoice-forge-1.20.1-2.0.7.jar"]

if isBadComputer == True:
    rsp = input("Del 1 a 5.. ¿Que tal mala es tu PC?\n(Menos mods opcionales instalados mientras el número sea mayor):\n\n1.Minecraft sin optifine con gráficos bajos funciona con 60 FPS promedio.\n(Obtendrás todos los mods opcionales excepto 'what the hell is that' y su dependencia)\nMods:\n-Inventory Profiler Next\n-Kotling For Forge(Dependencia de 'Inventory')\n-LibIPN(Dependencia de 'Inventory')\n-Just Enough Items\n-Xaero's minimap\n-Plasmo voice\n\n2.Minecraft sin optifine con gráficos bajos funciona con 50 FPS promedio.\n(Obtendrás todos los mods opcionales excepto 'What the hell is that'(con 'Bad packets') e 'Inventory Profiler Next' con sus dependencias)\nMods:\n-Just Enough Items\n-Xaero's minimap\n-Plasmo Voice \n\n3.Minecraft sin optifine con gráficos bajos funciona a 40 FPS promedio.\n(Igual que la opción anterior pero sin 'just Enough Items')\nMods:\n-Xaero's minimap\n-Plasmo Voice\n\n4.Minecraft sin optifine con gráficos bajos funciona a 30 FPS promedio.\n(PC de gobierno)\nMod:\n-Plasmo voice\n\n5.Minecraft sin optifine con gráficos bajos a 20 FPS\n(Absoluta mierda)\n-Sin mods opcionales\nTu respuesta(Lee todo antes de continuar):")
    response = rsp.lower()
    if response.startswith("1") or response.startswith("one") or response.startswith("uno"):
        removeFirstItem(optionalMods,2) 
    if response.startswith("2") or response.startswith("two") or response.startswith("do"):
        removeFirstItem(optionalMods,5) 
    if response.startswith("3") or response.startswith("three") or response.startswith("tre"):
        removeFirstItem(optionalMods,6) 
    if response.startswith("4") or response.startswith("four") or response.startswith("cuatr"):
        removeFirstItem(optionalMods,7) 
    if response.startswith("5") or response.startswith("five") or response.startswith("cinc"):
        optionalMods = []
seperator()

print("-Preparando mods para ser copiado-")
os.chdir(requiredModFolder)
requiredMods = os.listdir()

seperator()

modsFolderDetected = False
os.chdir(minecraftFolder)
minecraftItems = os.listdir()
if "mods" in minecraftItems:
    modsFolderDetected = True

if modsFolderDetected == True:
    print("-Vaciando carpeta de mods-")
    shutil.rmtree(f"{minecraftFolder}\\mods")
os.mkdir('mods')

print("-Copiando mods requeridos-")
for mod in requiredMods:
    shutil.copy(f"{requiredModFolder}\\{mod}",f"{minecraftFolder}\\mods\\{mod}")

print("-Copiando mods opcionales-")
for mod in optionalMods:
    shutil.copy(f"{optionalModFolder}\\{mod}",f"{minecraftFolder}\\mods\\{mod}")

seperator()

input("Mods de TronadoHard instalados! \nSi tenés problemas de rendimiento, podés usar el 'Bajador De Gráficos 3000'\n(Para más informacion, mira el tutorial o lee las instrucciones de como usarlo, o de como bajar los gráficos manualmente). \nPreciona enter y espera 2 segundos para que la instalacion completa termine exitosamente!\n(no cierres esta ventana, preciona enter y se cerrara solo)")


time.sleep(2)
